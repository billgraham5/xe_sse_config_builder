# IOS-XE Secure Access Config Builder (Web)

Static local web app that reproduces the usable parts of your workbook:
- `IPSEC_BGP_XE_CONFIG` input cells
- `_cfg_parts` generated IOS-XE CLI sections

## Run From Local Disk

1. Open `/Users/jack/Documents/New project/index.html` in Safari/Chrome.
2. Enter values and click **Generate**.
3. Use **Copy** or **Download .txt**.

No install, server, or internet access required.

## Input Mapping Used

- Router 1: `C4, C8, C9, C12, C13, C16, C17, C35`
- Router 2: `C5, C20, C21, C24, C25, C28, C29, C56`
- Shared: `C32, C79, C80`

Tunnel interface host IP derivation:
- Tunnel1 = base `+0`
- Tunnel2 = base `+1`
- Tunnel11 = base `+10`
- Tunnel12 = base `+11`
