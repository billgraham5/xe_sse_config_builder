function value(id) {
  return document.getElementById(id).value.trim();
}

function checked(id) {
  return document.getElementById(id).checked;
}

function addToIPv4(ip, offset) {
  const parts = ip.split(".").map(Number);
  if (parts.length !== 4 || parts.some((n) => Number.isNaN(n) || n < 0 || n > 255)) {
    throw new Error(`Invalid IP address: ${ip}`);
  }
  const last = parts[3] + offset;
  if (last > 254) {
    throw new Error(`Invalid tunnel base IP ${ip}: +${offset} exceeds .254`);
  }
  parts[3] = last;
  return parts.join(".");
}

function ikeProfile(name, remoteIP, localEmail) {
  return [
    `crypto ikev2 profile ${name}`,
    ` match identity remote address ${remoteIP} 255.255.255.255`,
    ` identity local email ${localEmail}`,
    " authentication remote pre-share",
    " authentication local pre-share",
    " keyring local sse-kr",
    " dpd 10 3 periodic",
    "!"
  ];
}

function loopback(num, desc) {
  return [
    `interface Loopback${num}`,
    ` description ${desc}`,
    ` ip address 100.64.255.${num} 255.255.255.255`,
    " ip nat inside",
    "!"
  ];
}

function tunnel(num, address, sourceLoopback, destination, profile) {
  return [
    `interface Tunnel${num}`,
    ` ip address ${address} 255.255.255.255`,
    " ip tcp adjust-mss 1350",
    ` tunnel source Loopback${sourceLoopback}`,
    " tunnel mode ipsec ipv4",
    ` tunnel destination ${destination}`,
    ` tunnel protection ipsec profile ${profile}`,
    "!"
  ];
}

function buildRouter(router, psk, advSdwan, advCloud) {
  const t1 = addToIPv4(router.baseIP, 0);
  const t2 = addToIPv4(router.baseIP, 1);
  const t11 = addToIPv4(router.baseIP, 10);
  const t12 = addToIPv4(router.baseIP, 11);

  const lines = [
    `! Generated for ${router.name}`,
    "crypto ikev2 proposal sse-proposal",
    " encryption aes-gcm-256",
    " prf sha256",
    " group 20",
    "!",
    "crypto ikev2 policy sse-policy",
    " proposal sse-proposal",
    "!",
    "crypto ikev2 keyring sse-kr",
    " peer sse-secondary",
    `  address ${router.secondaryIP}`,
    `  pre-shared-key local ${psk}`,
    `  pre-shared-key remote ${psk}`,
    " !",
    " peer sse-primary",
    `  address ${router.primaryIP}`,
    `  pre-shared-key local ${psk}`,
    `  pre-shared-key remote ${psk}`,
    " !",
    "!",
    "!"
  ];

  lines.push(...ikeProfile("sse-primary-1", router.primaryIP, `${router.name}+tunnel1@${router.primaryId}-sse.cisco.com`));
  lines.push(...ikeProfile("sse-primary-2", router.primaryIP, `${router.name}+tunnel2@${router.primaryId}-sse.cisco.com`));
  lines.push(...ikeProfile("sse-secondary-1", router.secondaryIP, `${router.name}+tunnel1@${router.secondaryId}-sse.cisco.com`));
  lines.push(...ikeProfile("sse-secondary-2", router.secondaryIP, `${router.name}+tunnel2@${router.secondaryId}-sse.cisco.com`));

  lines.push(
    "!",
    "crypto ipsec transform-set sse-ts esp-gcm 256",
    " mode tunnel",
    "!",
    "crypto ipsec profile sse-ipsec-primary-1",
    " set transform-set sse-ts",
    " set ikev2-profile sse-primary-1",
    "!",
    "crypto ipsec profile sse-ipsec-primary-2",
    " set transform-set sse-ts",
    " set ikev2-profile sse-primary-2",
    "!",
    "crypto ipsec profile sse-ipsec-secondary-1",
    " set transform-set sse-ts",
    " set ikev2-profile sse-secondary-1",
    "!",
    "crypto ipsec profile sse-ipsec-secondary-2",
    " set transform-set sse-ts",
    " set ikev2-profile sse-secondary-2",
    "!",
    "!",
    "!",
    "!",
    "!"
  );

  lines.push(...loopback(1, "source for interface tunnel 1"));
  lines.push(...loopback(2, "source for interface tunnel 2"));
  lines.push(...loopback(11, "source for interface tunnel 11"));
  lines.push(...loopback(12, "source for interface tunnel 12"));

  lines.push(...tunnel(1, t1, 1, router.primaryIP, "sse-ipsec-primary-1"));
  lines.push(...tunnel(2, t2, 2, router.primaryIP, "sse-ipsec-primary-2"));
  lines.push(...tunnel(11, t11, 11, router.secondaryIP, "sse-ipsec-secondary-1"));
  lines.push(...tunnel(12, t12, 12, router.secondaryIP, "sse-ipsec-secondary-2"));

  lines.push(
    "interface GigabitEthernet1",
    " ip nat outside",
    "",
    `router bgp ${router.asn}`,
    ` bgp router-id ${router.rid}`,
    " bgp log-neighbor-changes",
    " neighbor CISCO_SSE peer-group",
    " neighbor CISCO_SSE remote-as 32644",
    " neighbor 169.254.0.1 peer-group CISCO_SSE",
    " neighbor 169.254.0.1 ebgp-multihop 255",
    " neighbor 169.254.0.1 update-source Tunnel1",
    " neighbor 169.254.0.2 peer-group CISCO_SSE",
    " neighbor 169.254.0.2 ebgp-multihop 255",
    " neighbor 169.254.0.2 update-source Tunnel2",
    " neighbor 169.254.0.11 peer-group CISCO_SSE",
    " neighbor 169.254.0.11 ebgp-multihop 255",
    " neighbor 169.254.0.11 update-source Tunnel11",
    " neighbor 169.254.0.12 peer-group CISCO_SSE",
    " neighbor 169.254.0.12 ebgp-multihop 255",
    " neighbor 169.254.0.12 update-source Tunnel12",
    " !",
    " address-family ipv4",
    "  neighbor CISCO_SSE send-community both",
    "  neighbor CISCO_SSE soft-reconfiguration inbound",
    "  neighbor CISCO_SSE route-map FROM_SSE_IMPORT in",
    "  neighbor CISCO_SSE route-map TO_SSE_EXPORT out",
    " exit-address-family",
    "!",
    "ip route 169.254.0.1 255.255.255.255 Tunnel1",
    "ip route 169.254.0.2 255.255.255.255 Tunnel2",
    "ip route 169.254.0.11 255.255.255.255 Tunnel11",
    "ip route 169.254.0.12 255.255.255.255 Tunnel12",
    "",
    "ip nat inside source list SSE_IKE_NAT interface GigabitEthernet1 overload",
    "",
    "ip access-list extended SSE_IKE_NAT",
    " 10 permit ip 100.64.255.0 0.0.0.255 any",
    "",
    "route-map FROM_SSE_IMPORT deny 999",
    "ip bgp-community new-format",
    ""
  );

  if (advCloud) {
    lines.push(
      "route-map TO_SSE_EXPORT permit 5",
      " match ip address prefix-list AZURE_CENTRAL_PREFIXES",
      " set as-path prepend 64514 64514 64514",
      "!"
    );
  }

  if (advSdwan) {
    lines.push(
      "route-map TO_SSE_EXPORT permit 10",
      " match ip address prefix-list RFC1918_SUMMARIES",
      " set as-path prepend 64514 64514 64514",
      "!",
      "route-map TO_SSE_EXPORT permit 15",
      " match ip address prefix-list CISCO_MGMT_IOS",
      " set as-path prepend 64514 64514",
      "!"
    );
  }

  lines.push("!", "!", "!", "!");
  return lines.join("\n");
}

function collect() {
  const router1 = {
    name: value("r1Name"),
    primaryIP: value("r1PrimaryIP"),
    primaryId: value("r1PrimaryId"),
    secondaryIP: value("r1SecondaryIP"),
    secondaryId: value("r1SecondaryId"),
    rid: value("r1Rid"),
    asn: value("r1Asn"),
    baseIP: value("r1BaseIP")
  };
  const router2 = {
    name: value("r2Name"),
    primaryIP: value("r2PrimaryIP"),
    primaryId: value("r2PrimaryId"),
    secondaryIP: value("r2SecondaryIP"),
    secondaryId: value("r2SecondaryId"),
    rid: value("r2Rid"),
    asn: value("r2Asn"),
    baseIP: value("r2BaseIP")
  };
  return {
    router1,
    router2,
    psk: value("psk"),
    advSdwan: checked("advSdwan"),
    advCloud: checked("advCloud")
  };
}

function generate() {
  const out = document.getElementById("output");
  const err = document.getElementById("error");
  try {
    const input = collect();
    const config = [
      buildRouter(input.router1, input.psk, input.advSdwan, input.advCloud),
      buildRouter(input.router2, input.psk, input.advSdwan, input.advCloud)
    ].join("\n\n");
    out.value = config;
    err.textContent = "";
  } catch (e) {
    out.value = "";
    err.textContent = e.message || "Failed to generate config.";
  }
}

document.getElementById("generate").addEventListener("click", generate);
document.getElementById("copy").addEventListener("click", async () => {
  const text = document.getElementById("output").value;
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
  } catch (_) {
    document.getElementById("output").select();
    document.execCommand("copy");
  }
});

document.getElementById("download").addEventListener("click", () => {
  const text = document.getElementById("output").value;
  if (!text) return;
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "ios-xe-sse-config.txt";
  a.click();
  URL.revokeObjectURL(url);
});

generate();
